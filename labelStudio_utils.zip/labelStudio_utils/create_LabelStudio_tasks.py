import re, json, argparse



def get_reddit_data(reddit_json):
    """Deserialises a JSON file storing raw Reddit data into a
    list of dictionaries and extracts all texts, either comments
    or posts, into a list.

    Args:
        reddit_json: path to a json file storing reddit data.

    Returns:
        a list of texts, either comments or posts.

    Raises:
        FileNotFoundError: if the given .json file path is wrong.
    """
    with open(reddit_json, "r", encoding="utf-8") as from_json:
        json_data = json.load(from_json)

    key = "body" if "body" in json_data[0] else "selftext"
    text_data = [data.get(key) for data in json_data]

    return text_data



def clean_data(raw_text):
    """Removes most markdown formatting and punctuation symbols
    from the given Reddit comment or post.

    Args:
        raw_text: raw text of a Reddit comment or post.

    Returns:
        normalised text of a Reddit comment or post.
    """
    text = raw_text

    patterns = {
        r"\n+" : " ",					# replace newline \n with single space
        r"\"?!?\\?&[lg]t;!?\"?" : "",	# remove &gt;, &lt;, "\&gt;, &gt;! etc.
        r"\*" : "",						# remove bold/italic markdown symbol *
        r"~+" : "",						# remove strikethrough markdown symbol ~
        r"`+" : "",						# remove code-block markdown symbol `
        r"#+\s" : "",					# remove heading(s) markdown symbol #
        r"(&amp;)(#x200B;)?" : "",		# remove &amp; and no-width space &amp;#x200B;
        r"\|" : " ",					# replace table column symbol with a space
        r":-" : "",						# remove table row markdown symbol
        r"\[.+?\]\(.+?\)" : "",			# remove links e.g. [foo](https://bar/)
        r"\^\((.+?)\)" : r"\1",			# extract text from superscript syntax
        r"\s\s+" : " "}					# replace multiple spaces with a single one

    for pattern, replacement in patterns.items():
        text = re.sub(pattern, replacement, text)

    return text.strip()



def create_tasks(reddit_data):
    """Encodes Reddit data into a JSON-formatted list of tasks
    suitable to be imported and annotated in Label Studio.

    Each task consists of a key-value pair, where the key, `reddit`,
    defines a single task. For example:
    ```
    [{ "reddit": "Super Bullish!" },
    { "reddit": "Bitcoint to the moon!" }]
    ```

    Args:
        reddit_data: a list of texts, either comments or posts.

    Returns:
        None
    """
    with open("CryptoCurrency_tasks.json", "w", encoding="UTF-8") as json_out:
        tasks = [{"reddit":clean_data(item)} for item in reddit_data]
        print(f"number of tasks created: {len(tasks)}")
        json.dump(tasks, json_out, indent=1, ensure_ascii=False)



def main(args):
    try:
        # store reddit comments and posts into a single list
        reddit_data = [*get_reddit_data(args.comments), *get_reddit_data(args.posts)]
        # store reddit comments and posts as a JSON-formatted list of tasks
        create_tasks(reddit_data)
    except FileNotFoundError as fe:
        print(str(fe))



def parse_arguments():
    parser = argparse.ArgumentParser(
        description="A script to convert reddit data into Label Studio tasks.",
        usage="create_LabelStudio_tasks.py [-h] reddit_comments.json reddit_posts.json")
    parser.add_argument("comments", help="path to a json file storing reddit comments")
    parser.add_argument("posts", help="path to a json file storing reddit posts")
    args = parser.parse_args()

    return args



if __name__ == '__main__':
    args = parse_arguments()
    main(args)
