import spacy
from tabulate import tabulate
from label_studio.ml import LabelStudioMLBase



class SpacyNER(LabelStudioMLBase):

    def __init__(self, **kwargs):

        # call LabelStudioMLBase constructor
        super(SpacyNER, self).__init__(**kwargs)

        from_name, schema = list(self.parsed_label_config.items())[0]
        self.from_name = from_name
        self.to_name = schema["to_name"][0]
        self.labels = schema["labels"]
        self.key_name = schema["inputs"][0]["value"]
        self.nlp = spacy.load("en_core_web_sm")

        # add the Entity Ruler to the nlp pipeline
        self.ruler = self.nlp.add_pipe("entity_ruler", after="ner",
            config={"validate": True, "overwrite_ents": True})

        # add patterns for most common cryptocurrencies
        self.ruler.from_disk("./crypto_patterns.jsonl")

        # print summary of the current SpacyNER instance
        summary = [["from_name", f"{self.from_name}"], ["to_name", f"{self.to_name}"],
            ["labels", f"{self.labels}"], ["key_name", f"{self.key_name}"]]
        print("Backend initialised with the following values:",
            tabulate(summary, tablefmt="fancy_grid"), sep="\n")



    def predict(self, tasks, **kwargs):
        """Provides assitance in the annotation process by returning
        a label for each recognised entity in a given task.

        Labels are the result of a naive rule-based matching carried
        out by Spacy's Entity Ruler on the basis of the patterns in
        the .jsonl file `Crypto_patterns.jsonl`.

        Args:
            tasks: list of Reddit comments and posts encoded as taks to
            be annotated.

        Returns:
            a list of naively predicted labels for all recognized entities
            in the given tasks.
        """
        predictions = []
        for task in tasks:
            results = []
            text = task["data"][self.key_name]
            doc = self.nlp(text)

            # add a prediction for each CRYPTOCURRENCY entity found
            for ent in doc.ents:
                if ent.label_ == "CRYPTOCURRENCY":
                    # prediction results for the single task doc
                    result = {
                        "from_name": self.from_name,
                        "to_name": self.to_name,
                        "type": "labels",
                        "value": {
                            "start": ent.start_char,
                            "end": ent.end_char,
                            "text" : ent.text,
                            "labels": [ent.label_]
                        }
                    }
                    results.append(result)

            predictions.append({"result": results})

        return predictions
